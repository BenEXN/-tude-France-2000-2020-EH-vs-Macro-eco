
#!/usr/bin/env python3
import argparse, pandas as pd, numpy as np
from pathlib import Path

def read_csv(path, required=None):
    df = pd.read_csv(path)
    if required:
        for c in required:
            if c not in df.columns:
                raise ValueError(f"Missing {c} in {path}")
    return df

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--m3", required=True)
    ap.add_argument("--gdp", required=True)
    ap.add_argument("--pop", required=True)
    ap.add_argument("--pay", required=True)
    ap.add_argument("--countries", required=False)
    ap.add_argument("--y0", type=int, required=True)
    args = ap.parse_args()

    m3 = read_csv(args.m3)
    gdp = read_csv(args.gdp)
    pop = read_csv(args.pop)
    pay = read_csv(args.pay)

    # Basic checks
    for df in [m3,gdp,pop]:
        df["year"] = pd.to_numeric(df["year"], errors="coerce")

    pay["year_ref"] = pd.to_numeric(pay["year_ref"], errors="coerce")

    merged = m3.merge(gdp[["iso3","gdp_usd"]], on="iso3", how="outer") \
               .merge(pop[["iso3","population_total"]], on="iso3", how="outer") \
               .merge(pay[["iso3","year_ref","total_transactions_count","total_transactions_value_usd"]], on="iso3", how="left")

    merged.to_csv("oecd_eh_monetary_Y0.csv", index=False)
    print("Merged file written: oecd_eh_monetary_Y0.csv")

if __name__ == "__main__":
    main()
