
# EH Monétaire Planétaire – Paquet OCDE (Y₀)

Ce dossier contient les gabarits CSV et un script ETL/QA pour construire l’ensemble de données requis à Y₀.

## Fichiers
- `oecd_m3_usd_Y0.csv` — M3 (monnaie locale + USD)
- `oecd_gdp_usd_Y0.csv` — PIB (USD courants)
- `oecd_population_Y0.csv` — Population totale
- `oecd_payments_Y0.csv` — Paiements sans numéraire
- `oecd_countries_Y0.csv` — Liste OCDE (optionnelle)
- `etl_oecd_y0.py` — Script ETL + QA

## Instructions
1. Compléter les CSV avec les données OCDE/IMF/WDI/BIS/ONU WPP pour l’année Y₀.
2. Exécuter le script :
   ```bash
   python etl_oecd_y0.py --m3 oecd_m3_usd_Y0.csv --gdp oecd_gdp_usd_Y0.csv --pop oecd_population_Y0.csv --pay oecd_payments_Y0.csv --countries oecd_countries_Y0.csv --y0 2000
   ```
3. Résultats :
   - `oecd_eh_monetary_Y0.csv` — table fusionnée
   - `oecd_flags_Y0.csv` — flags/outliers
   - `QA_report_Y0.txt` — rapport qualité
